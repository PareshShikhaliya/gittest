package ninth;

public class Example1 {
    public static void main(String[] args) {
        final double PI = 3.14159; // declaring pi as a constant

        double radius = 5.0;
        double area = PI * radius * radius; // calculating the area of the circle

        System.out.println("The area of the circle is: " + area); // printing the result
    }
}

