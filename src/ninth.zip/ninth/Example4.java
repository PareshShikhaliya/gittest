package ninth;

public class Example4 {
    private int x = 10; // instance variable

    public void printX() {
        int x = 5; // local variable that hides the instance variable

        System.out.println("Local variable x = " + x); // prints 5
        System.out.println("Instance variable x = " + this.x); // prints 10
    }
}



