package ninth;


public class Example6 {
    public static void main(String[] args) {
        System.out.println("This is a regular string.");
        System.out.println("This string has a \"double quote\" in it.");
        System.out.println("This string has a \'single quote\' in it.");
        System.out.println("This string has a \\backslash\\ in it.");
        System.out.println("This string has a \nnew line in it.");
        System.out.println("This string has a \ttab character in it.");
    }
}
