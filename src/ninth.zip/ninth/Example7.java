package ninth;


public class Example7 {
    public static void main(String[] args) {
        System.out.println("This is a string with a \r carriage return in it.");
        System.out.println("This is a string with a \f form feed in it.");
        System.out.println("This is a string with a \b backspace in it.");
        System.out.println("This is a string with a \\\\ escaped backslash in it.");
    }
}
