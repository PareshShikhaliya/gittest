package class11;

public class Example1 {
    public static void main(String[] args) {
        byte byteValue = 100;
        short shortValue = 30000;
        int intValue = 2000000000;
        long longValue = 9000000000000000000L;
        float floatValue = 3.14f;
        double doubleValue = 3.14159d;
        boolean booleanValue = true;
        char charValue = 'A';
        
        float number = 10.0f;
        float number2 = 0.0f;
        float number3 = number/number2;


        System.out.println("number3 " + number3);
     
    }
}

