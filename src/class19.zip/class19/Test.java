package class19;

public class Test {
    public static void main(String[] args) {

        final int v1 = 10;
        System.out.println(v1);

    }
}