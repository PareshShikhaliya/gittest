package class14;

public class ClassExample {
    public static void main(String[] args) {
        Class a = "Hello".getClass();
        System.out.println("Class a: " + a);

    }
}
