package third;

import java.util.Scanner;


public class IFEXample7 {
    public static void main(String[] args) {
        int age = 18;
        String message = (age >= 18) ? "You are an adult" : "You are not an adult";
        System.out.println(message);

        if(age>=18)
        {
            System.out.println("You are an adult");
        }
        else {
            System.out.println("You are not an adult");
        }

    }
}
