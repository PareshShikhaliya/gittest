package third;

public class StatementExpression {

    public static void main(String args[])
    {
        int x = 5;
        int y = 10;
        int z = x + y;

        if (z > 15) {
            System.out.println("The value of z is greater than 15.");
        }


    }
}



